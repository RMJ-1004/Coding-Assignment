from typing import Any, Callable, Dict, List
from app.models import State, GraphDef, NodeDef
from app.tools import get_tool   # IMPORTANT
import uuid

GRAPHS: Dict[str, 'Graph'] = {}
RUNS: Dict[str, Dict[str, Any]] = {}

class Node:
    def __init__(self, name: str, fn: Callable[[State], State]):
        self.name = name
        self.fn = fn

class Graph:
    def __init__(self, nodes: Dict[str, Node], edges: Dict[str, Any]):
        self.nodes = nodes
        self.edges = edges

class Engine:
    @staticmethod
    def create_graph(graph_def: GraphDef) -> str:
        nodes = {}
        for node_def in graph_def.nodes:
            fn = get_tool(node_def.function)
            if not fn:
                raise ValueError(f"Tool not found: {node_def.function}")
            nodes[node_def.name] = Node(node_def.name, fn)

        graph = Graph(nodes, graph_def.edges)
        graph_id = str(uuid.uuid4())
        GRAPHS[graph_id] = graph
        return graph_id

    @staticmethod
    def run_graph(graph_id: str, initial_state: Dict[str, Any]):
        graph = GRAPHS.get(graph_id)
        if not graph:
            raise ValueError("Graph not found")

        state = State(data=initial_state)
        log = []
        current_node = "start"

        while current_node and current_node != "end":
            if current_node not in graph.nodes:
                log.append(f"Error: node {current_node} not found")
                break

            node = graph.nodes[current_node]
            log.append(f"Executing {current_node}")
            state = node.fn(state)

            edge = graph.edges.get(current_node)

            if isinstance(edge, str):
                current_node = edge
            elif isinstance(edge, dict):
                condition = edge.get("condition", "")
                if eval(condition, {"__builtins__": None}, state.data):
                    current_node = edge.get("then", "end")
                else:
                    current_node = edge.get("else", "end")
            else:
                current_node = None

        run_id = str(uuid.uuid4())
        RUNS[run_id] = {"state": state.data, "log": log}
        return state.data, log, run_id
