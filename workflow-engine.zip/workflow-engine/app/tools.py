# app/tools.py
from typing import Any, Callable, Dict
from app.models import State

TOOLS: Dict[str, Callable[[State], State]] = {}

def register_tool(name: str, fn: Callable[[State], State]):
    TOOLS[name] = fn

def get_tool(name: str):
    return TOOLS.get(name)

# Sample tools
def extract_functions(state: State) -> State:
    code = state.data.get("code", "")
    functions = code.count("def ")
    state.data["functions"] = functions
    state.data["quality_score"] = 0
    return state

def check_complexity(state: State) -> State:
    code = state.data.get("code", "")
    complexity = len(code.split("\n"))
    state.data["complexity"] = complexity
    return state

def detect_issues(state: State) -> State:
    code = state.data.get("code", "")
    issues = code.count("TODO") + sum(1 for line in code.split("\n") if len(line) > 80)
    state.data["issues"] = issues
    return state

def suggest_improvements(state: State) -> State:
    issues = state.data.get("issues", 0)
    state.data["suggestions"] = [f"Fix issue {i+1}" for i in range(issues)]
    state.data["quality_score"] += 1
    return state

# register tools (correct names)
register_tool("extract_functions", extract_functions)
register_tool("check_complexity", check_complexity)
register_tool("detect_issues", detect_issues)
register_tool("suggest_improvements", suggest_improvements)
