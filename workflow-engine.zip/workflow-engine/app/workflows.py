from app.engine import Engine
from app.models import GraphDef, NodeDef

def create_sample_graph():
    graph_def = GraphDef(
        nodes=[
            NodeDef(name="start", function="extract_functions"),
            NodeDef(name="extract_functions", function="extract_functions"),
            NodeDef(name="check_complexity", function="check_complexity"),
            NodeDef(name="detect_issues", function="detect_issues"),
            NodeDef(name="suggest_improvements", function="suggest_improvements"),
        ],
        edges={
            "start": "extract_functions",
            "extract_functions": "check_complexity",
            "check_complexity": "detect_issues",
            "detect_issues": "suggest_improvements",
            "suggest_improvements": {
                "condition": "quality_score >= 5",
                "then": "end",
                "else": "check_complexity"
            }
        }
    )

    return Engine.create_graph(graph_def)

DEFAULT_GRAPH_ID = create_sample_graph()
