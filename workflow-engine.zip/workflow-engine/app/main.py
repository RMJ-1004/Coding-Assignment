from fastapi import FastAPI, HTTPException
from app.models import (
    CreateGraphRequest, CreateGraphResponse, RunGraphRequest, RunGraphResponse, GetStateResponse
)
from app.engine import Engine, RUNS
from app.workflows import DEFAULT_GRAPH_ID  # Initialize sample graph

app = FastAPI()

@app.post("/graph/create", response_model=CreateGraphResponse)
def create_graph(request: CreateGraphRequest):
    try:
        graph_id = Engine.create_graph(request.graph_def)
        return CreateGraphResponse(graph_id=graph_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/graph/run", response_model=RunGraphResponse)
def run_graph(request: RunGraphRequest):
    try:
        final_state, log, run_id = Engine.run_graph(request.graph_id, request.initial_state)
        return RunGraphResponse(run_id=run_id, final_state=final_state, log=log)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/graph/state/{run_id}", response_model=GetStateResponse)
def get_state(run_id: str):
    run_data = RUNS.get(run_id)
    if not run_data:
        raise HTTPException(status_code=404, detail="Run not found")
    return GetStateResponse(state=run_data["state"], log=run_data["log"])

# For quick testing: Run the sample workflow
@app.post("/sample/run")
def run_sample(initial_state: dict):
    final_state, log, run_id = Engine.run_graph(DEFAULT_GRAPH_ID, initial_state)
    return {"run_id": run_id, "final_state": final_state, "log": log}
