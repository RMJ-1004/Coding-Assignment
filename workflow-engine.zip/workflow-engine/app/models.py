from pydantic import BaseModel
from typing import Any, Dict, List, Optional, Union

# Shared state: a dict that flows through nodes
class State(BaseModel):
    data: Dict[str, Any] = {}

    def dict(self) -> Dict[str, Any]:
        return self.data

# Node definition for API (name + function name to bind)
class NodeDef(BaseModel):
    name: str
    function: str  # e.g., "extract_functions" – we'll bind to actual functions later

# Graph definition for API
# edges can be a simple mapping to the next node (str)
# or a dict for conditional/loop routing (e.g. {"condition": "quality_score >= 5", "then": "end", "else": "loop"})
EdgeType = Union[str, Dict[str, Any]]

class GraphDef(BaseModel):
    nodes: List[NodeDef]
    edges: Dict[str, EdgeType]

# API request/response models
class CreateGraphRequest(BaseModel):
    graph_def: GraphDef

class CreateGraphResponse(BaseModel):
    graph_id: str

class RunGraphRequest(BaseModel):
    graph_id: str
    initial_state: Dict[str, Any]

class RunGraphResponse(BaseModel):
    run_id: str
    final_state: Dict[str, Any]
    log: List[str]

class GetStateResponse(BaseModel):
    state: Dict[str, Any]
    log: List[str]
